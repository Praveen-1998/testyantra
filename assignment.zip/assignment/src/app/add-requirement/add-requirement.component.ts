import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-add-requirement',
  templateUrl: './add-requirement.component.html',
  styleUrls: ['./add-requirement.component.css']
})
export class AddRequirementComponent implements OnInit {
  reqForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.reqForm = this.fb.group({
      companyName : this.fb.control('',
        [
          Validators.minLength(3),
          Validators.maxLength(30),
          Validators.required
        ]),
      location : this.fb.control(''),
      candidates: this.fb.array([
        this.candidate()
      ])
    });
  }

  candidate(): FormGroup {
    return this.fb.group({
      fullname: this.fb.control(''),
      degper: this.fb.control(''),
      stack: this.fb.control('')
    })
  }

  addCandidate() {
    (this.reqForm.get('candidates') as FormArray).push(this.candidate());
  }

  removeCandidate(i: number) {
    (this.reqForm.get('candidates') as FormArray).removeAt(i);
  }

  printReqForm() {
    console.log(this.reqForm.value);
    this.reqForm.reset();
  }
}
