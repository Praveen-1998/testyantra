import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomValidator } from './custom.validator'

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent implements OnInit {

  constructor() { }
  get fname() {
    return this.registerForm.get('fname');
  }
  get lname() {
    return this.registerForm.get('lname');
  }
  get address() {
    return this.registerForm.get('address');
  }

  get email() {
    return this.registerForm.get('email');
  }
  get mobileno() {
    return this.registerForm.get('mobileno');
  }


  registerForm = new FormGroup({
    fname: new FormControl('', [Validators.minLength(3),  //form status and validator array
    Validators.required]),
    lname: new FormControl('', [Validators.minLength(3),
    Validators.required]),
    address: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.email, Validators.minLength(5), Validators.required , CustomValidator.noSpace]),
    mobileno: new FormControl('', [Validators.minLength(10), Validators.required])
  })
  ngOnInit() {
  }

}
