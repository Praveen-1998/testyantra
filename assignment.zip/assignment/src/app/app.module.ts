import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { AddProductComponent } from './add-product/add-product.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ReactiveformComponent } from './reactiveform/reactiveform.component';
import { TemplatedrivenformComponent } from './templatedrivenform/templatedrivenform.component';
import { AddRequirementComponent } from './add-requirement/add-requirement.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    AddProductComponent,
    ProductDetailsComponent,
    ReactiveformComponent,
    TemplatedrivenformComponent,
    AddRequirementComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path : '' , component : HomeComponent},
      { path : 'addProdcut' , component : AddProductComponent},
      { path : 'prodDetails' , component : ProductDetailsComponent},
      { path : 'reactiveform' , component : ReactiveformComponent},
      { path : 'templatedrivenform' , component : TemplatedrivenformComponent},
      { path : 'add-requirement' , component : AddRequirementComponent}


    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
